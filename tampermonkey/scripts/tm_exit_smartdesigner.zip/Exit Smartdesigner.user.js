// ==UserScript==
// @name         Exit Smartdesigner
// @namespace    http://tampermonkey.net/
// @version      2025-04-09
// @description  Back to modules button when in SmartDesigner
// @author       Espen Raugstad
// @match        https://uia.instructure.com/courses/*/external_tools/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // Breadcrumbs
    const bc = document.querySelector(".ic-app-crumbs");

    // Create a new div
    let div = document.createElement("div");

    // Get the page title from the url query parameter
    const url = new URLSearchParams(location.search);
    const page = url.get("page");

    // Add Moduler and Sider as buttons
    div.innerHTML = `
    <a href="https://uia.instructure.com/courses/${ENV.current_context.id}/pages/${page}" role="button" class="Button Button--primary">Gå ut av SmartDesigner</a>
    `;
    bc.insertAdjacentElement("afterend", div);

})();