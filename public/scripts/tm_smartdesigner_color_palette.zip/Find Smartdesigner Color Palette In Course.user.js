// ==UserScript==
// @name         Find Smartdesigner Color Palette In Course
// @namespace    http://tampermonkey.net/
// @version      2025-10-07
// @description  Find Smartdesigner Color Palette In Course
// @author       Espen Raugstad
// @match        https://uia.instructure.com/courses/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    /*** GLOBAL VARIABLES - START ***/
    let paletteRegistry = null;
    const BASE_URL = "https://uia.instructure.com";
    const COURSE_ID = getCourseId();
    const MAX_PER_PAGE = 100;

    let report = "Type;Tittel;Palett\n";

    const currentStatus = {
        "search": "&#128270",
        "found": "&#9989;",
        "none": "&#10060;",
        "forbidden": "&#128683;"
    }

    let progressStatus = null;
    let announcementStatus = null;
    let assignmentStatus = null;
    let discussionStatus = null;
    let pageStatus = null;
    let syllabusStatus = null;

    /*** GLOBAL VARIABLES - END ***/

    window.addEventListener("load", async (e)=>{
        await getPaletteRegistry();
        addUi();
    });

    async function runChecks(){
        progressStatus = document.getElementById("_uia_audit_status");
        progressStatus.style.display = "block";

        announcementStatus = document.getElementById("_uia_audit_announcement_status");
        assignmentStatus = document.getElementById("_uia_audit_assignment_status");
        discussionStatus = document.getElementById("_uia_audit_discussion_status");
        pageStatus = document.getElementById("_uia_audit_page_status");
        syllabusStatus = document.getElementById("_uia_audit_syllabus_status");


        let announcementsFound = await checkAnnouncements();
        let assignmentsFound = await checkAssignments();
        let discussionsFound = await checkDiscussions();
        let pagesFound = await checkPages();
        let syllabusFound = await checkSyllabusPage();

        let reportable = announcementsFound || assignmentsFound || discussionsFound || pagesFound || syllabusFound;
        if(reportable){
            getReport();
        }else {
            let reportDiv = document.getElementById("_uia_audit_report");
            reportDiv.innerHTML = "Fant ingen bruk av Smartdesigner i dette emnet 😊";
            console.log("No smartdesigner found");
        }
    }

    /*** UI ***/
    async function addUi(){
        /* DIALOG */
        const dialog = document.createElement("dialog");
        dialog.id = "_uia_audit_dialog";
        const dialogHTML = `
        <div>
        <h2>Fargepaletter</h2>
        <p>Sjekk om det brukt fargepaletter fra Smartdesigner i dette emnet.</p>
        <div id="_uia_audit_status" style="display:none; margin-bottom: 0.5rem;">
        <h3>Status</h3>
        <ul>
        <li id="_uia_audit_announcement_status">Kunngjøringer</li>
        <li id="_uia_audit_assignment_status">Oppgaver</li>
        <li id="_uia_audit_discussion_status">Diskusjoner</li>
        <li id="_uia_audit_page_status">Sider</li>
        <li id="_uia_audit_syllabus_status">Emneoversikt</li>
        </ul>
        </div>
        <div id="_uia_audit_report" style="margin-bottom:0.5rem;">

        </div>
        </div>
        <div style="display: flex; justify-content: space-between">
        <button id="_uia_run_audit_btn" class="Button Button--success">Finn paletter</button>
        <button id="_uia_audit_dialog_close_btn" class="Button Button--danger">Lukk</button>
        </div>
        `;
        dialog.innerHTML = dialogHTML;

        document.body.appendChild(dialog);

        /* RUN BUTTON */
        const topBar = document.querySelector(".ic-app-nav-toggle-and-crumbs");
        const runButton = document.createElement("button");
        runButton.classList.add("Button", "Button--primary");
        runButton.style.marginLeft = "0.5rem";
        runButton.innerText = "Smartdesigner Fargepaletter";
        topBar.appendChild(runButton);

        runButton.addEventListener("click", modalDialog);


    }

    async function modalDialog(){
        const dialog = document.getElementById("_uia_audit_dialog");
        dialog.showModal();

        /* RUN BTN */
        const runBtn = document.getElementById("_uia_run_audit_btn");
        runBtn.addEventListener("click", runChecks);

        /* CLOSE BTN */
        const closeBtn = document.getElementById("_uia_audit_dialog_close_btn");
        closeBtn.addEventListener("click", ()=> {dialog.close();});
    }

    /*** CHECKS ***/
    /*** ANNOUNCEMENTS ***/
    async function checkAnnouncements(){
        announcementStatus.innerHTML += currentStatus.search;
        const API_URL = `/api/v1/courses/${COURSE_ID}/discussion_topics?only_announcements=true&per_page=${MAX_PER_PAGE}`;
        const announcements = await retrieve(BASE_URL + API_URL);
        let announcementFound = false;

        if(!announcements){
            announcementStatus.innerHTML = "Kunngjøringer" + currentStatus.forbidden;
            return announcementFound;
        }

        for(const announcement of announcements){
            const sd = getSmartdesigner(announcement.message);
            if(sd !== null){
                console.log("Smartdesigner detected in announcements");
                const palette = identifyPalette(sd);
                report += `Kunngjøring;${announcement.title};${palette}\n`;
                announcementFound = true;
            }
        }
        console.log("Checking announcements done");
        announcementFound ? announcementStatus.innerHTML = "Kunngjøringer" + currentStatus.found : announcementStatus.innerHTML = "Kunngjøringer" + currentStatus.none;
        return announcementFound;
    }

    /*** ASSIGNMENTS ***/
    async function checkAssignments(){
        assignmentStatus.innerHTML += currentStatus.search;
        const API_URL = `/api/v1/courses/${COURSE_ID}/assignments?per_page=${MAX_PER_PAGE}`;
        const assignments = await retrieve(BASE_URL + API_URL);
        let assignmentsFound = false;

        if(!assignments){
            assignmentStatus.innerHTML = "Oppgaver" + currentStatus.forbidden;
            return assignmentsFound;
        }

        for(const assignment of assignments){
            const sd = getSmartdesigner(assignment.description);
            if(sd !== null){
                console.log("Smartdesigner detected in assignments");
                const palette = identifyPalette(sd);
                report += `Oppgave;${assignment.name};${palette}\n`;
                assignmentsFound = true;
            }
        }
        console.log("Checking assignments done");
        assignmentsFound ? assignmentStatus.innerHTML = "Oppgaver" + currentStatus.found : assignmentStatus.innerHTML = "Oppgaver" + currentStatus.none;
        return assignmentsFound;
    }

    /*** DISCUSSION TOPICS ***/
    async function checkDiscussions(){
        discussionStatus.innerHTML += currentStatus.search;
        const API_URL = `/api/v1/courses/${COURSE_ID}/discussion_topics?per_page=${MAX_PER_PAGE}`;
        const discussions = await retrieve(BASE_URL + API_URL);
        let discussionsFound = false;

        if(!discussions){
            discussionStatus.innerHTML = "Diskusjoner" + currentStatus.forbidden;
            return discussionsFound;
        }

        for(const discussion of discussions){
            const sd = getSmartdesigner(discussion.message);
            if(sd !== null){
                console.log("Smartdesigner detected in discussions");
                const palette = identifyPalette(sd);
                report += `Diskusjon;${discussion.title};${palette}\n`;
                discussionsFound = true;
            }
        }
        console.log("Checking discussions done");
        discussionsFound ? discussionStatus.innerHTML = "Diskusjoner" + currentStatus.found : discussionStatus.innerHTML = "Diskusjoner" + currentStatus.none;
        return discussionsFound;
    }

    /*** PAGES ***/
    async function checkPages(){
        pageStatus.innerHTML += currentStatus.search;
        const API_URL = `/api/v1/courses/${COURSE_ID}/pages?per_page=${MAX_PER_PAGE}&include[]=body`;
        const pages = await retrieve(BASE_URL + API_URL);
        let pagesFound = false;

        if(!pages){
            pageStatus.innerHTML = "Sider" + currentStatus.forbidden;
            return pagesFound;
        }

        for(const page of pages){
            const sd = getSmartdesigner(page.body);
            if(sd !== null){
                console.log("Smartdesigner detected in pages");
                const palette = identifyPalette(sd);
                report += `Side;${page.title};${palette}\n`;
                pagesFound = true;
            }
        }
        console.log("Checking pages done");
        pagesFound ? pageStatus.innerHTML = "Sider" + currentStatus.found : pageStatus.innerHTML = "Sider" + currentStatus.none;
        return pagesFound;
    }

    /*** SYLLABUS PAGE ***/
    async function checkSyllabusPage(){
        syllabusStatus.innerHTML += currentStatus.search;
        const API_URL = `/api/v1/courses/${COURSE_ID}?include[]=syllabus_body`;
        const syllabus = await retrieve(BASE_URL + API_URL);
        let syllabusFound = false;

        if(!syllabus){
            syllabusStatus.innerHTML = "Emneoversikt" + currentStatus.forbidden;
            return syllabusFound;
        }

        const sd = getSmartdesigner(syllabus.syllabus_body);
        if(sd !== null){
            console.log("Smartdesigner detected in syllabus page");
            const palette = identifyPalette(sd);
            report += `Emneoversikt;-;${palette}`;
            syllabusFound = true;
        }

        console.log("Checking syllabus done");
        syllabusFound ? syllabusStatus.innerHTML = "Emneoversikt" + currentStatus.found : syllabusStatus.innerHTML = "Emneoversikt" + currentStatus.none;
        return syllabusFound;
    }

    /*** CHECK UTILITIES ***/

    function getSmartdesigner(html){
        const parser = new DOMParser();
        const d = parser.parseFromString(html, "text/html");
        const sd = d.querySelector("._smartdesigner");
        return sd;
    }

    async function retrieve(url){
        try{
            const res = await fetch(url);

            if(res.status !== 200){
                throw new Error(res.status);
            }

            const data = await res.json();
            return data;

        }catch(e){
            console.error(e);
            return null;
        }
    }

    /*** IDENTIFY ***/
    function identifyPalette(d){
        const everything = d.querySelectorAll("*");

        for(const el of everything){
            const color = el.style.color;
            const bg = el.style.backgroundColor;
            const border = el.style.borderColor;
            if(color.includes("--sd")){
                const palette = match(color);
                return palette;
            }
            if(bg.includes("--sd")){
                const palette = match(bg);
                return palette;
            }
            if(border.includes("--sd")){
                const palette = match(border);
                return palette;
            }
        }

        // No elements are found containing either background color, color, or border color.
        return "Color palette not applied to any elements.";
    }

    function match(c){
        const id = extractId(c);
        const paletteName = paletteRegistry[id];
        if(typeof paletteName !== "string"){
            return "Ukjent fargepalett";
        } else {
            return paletteRegistry[id];
        }
    }
    /*** REGISTRY ***/

    async function getPaletteRegistry(){
        const GSsid = "1x8JtCqQGkPXXQYDkK473B8dB9vlVWfwWDRyTjrR3Fik";
        const GSsname = encodeURIComponent("Registry");
        const GSurl = `https://docs.google.com/spreadsheets/d/${GSsid}/gviz/tq?tqx=out:csv&sheet=${GSsname}`;
        const GSres = await fetch(GSurl);
        const GSdata = await GSres.text();
        buildRegistry(GSdata);
    }

    function buildRegistry(data){
        const lines = data.split("\n");
        lines.shift();
        let kv = [];
        for(const line of lines){
            const [css, name] = line.split(",");
            kv.push([extractId(css), name]);
        }
        paletteRegistry = Object.fromEntries(kv);
        console.log("Registry done");
    }

    function extractId(v){
        const ar = v.split("-");
        return ar[3];
    }

    /*** REPORT ***/
    function getReport(){
        let reportDiv = document.getElementById("_uia_audit_report");
        const blob = new Blob(["\uFEFF"+report], { type: 'text/csv;charset=UTF-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.innerText = "Last ned rapport (CSV)";
        a.download = "Smartdesigner fargepalett rapport for " + ENV.current_context.name + ".csv";
        reportDiv.appendChild(a);
    }

    /*** MISCELLANEOUS UTILITIES ***/
    function getCourseId(){
        if (typeof window === 'undefined' || typeof window.ENV !== 'object') {
            return null;
        }

        if(window.ENV.COURSE_ID){
            return window.ENV.COURSE_ID;
        }

        if(window.ENV.COURSE.id){
            return window.ENV.COURSE.id;
        }

        if(window.ENV.current_context.id){
            return window.ENV.current_context.id;
        }

        return null;
    }
})();