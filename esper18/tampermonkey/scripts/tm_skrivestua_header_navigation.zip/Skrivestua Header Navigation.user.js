// ==UserScript==
// @name         Skrivestua Header Navigation
// @namespace    http://tampermonkey.net/
// @version      2025-05-05
// @description  Copy the header from one page and applies to all pages fitting certain criteria
// @author       Espen Raugstad
// @match        https://uia.instructure.com/courses/*/pages/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=instructure.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    /***** GLOBAL VARIABLES *****/
    const BASE_URL = "https://uia.instructure.com/";
    let updating = false;

    /***** START *****/
    const observer = new MutationObserver((mutations, observer)=>{
        for(const mutation of mutations){
            const headerBar = document.querySelector(".header-bar");
            if(headerBar){
                addButton(headerBar);
                observer.disconnect();
                return;
            }
        }
    });

    observer.observe(document.body, {childList: true, subtree: true})

    function addButton(headerBar){
        const updateBtn = document.createElement("button");
        updateBtn.innerText = "Oppdater header";
        updateBtn.classList.add("btn", "btn-info");
        updateBtn.style.marginLeft = "1rem";
        headerBar.appendChild(updateBtn);

        updateBtn.addEventListener("click", showModal);
    }

    async function updateHeader(){
        // Get header for current page, first by getting the content
        const content = document.querySelector(".user_content");
        const header = content.querySelector("header");

        // Get the input from the modal
        let pagesStartingWithElement = document.getElementById("uia__page_start");
        let pagesStartingWith = pagesStartingWithElement.value;
        console.log(pagesStartingWithElement);
        if(pagesStartingWith.trim() === ""){
            alert("Du har ikke spesifisert noen sider for oppdatering");
        } else {
            const course_id = ENV.COURSE_ID;
            const URL = BASE_URL + `api/v1/courses/${course_id}/pages?include[]=body`;
            const allPages = await getAllPages(URL, []);
            const pages = allPages.filter(page => validPage(page, pagesStartingWith));

            // Start a new modal that keeps track of progress.
            let [updater, finishBtn] = showProgressModal();
            updating = true;
            if(pages.length === 0){
                updater.innerHTML = "Fant ingen sider som kan oppdateres";
            } else {
                for(const page of pages){
                    if(!updating){
                        return;
                    }
                    updater.innerHTML = `Oppdaterer siden ${page.title}.`;
                    await updatePage(page, header);
                }
                updater.innerHTML = "Alle sidene oppdatert.";
            }
            finishBtn.innerText = "Ferdig"
        }
    }

    async function updatePage(page, header){
        // Skip updating the current page, which is the page we are updating from
        if(ENV.WIKI_PAGE.title === page.title){
            console.log(page.title);
            console.log("Not updating");
            return;
        }
        // Create a temporary div to hold the html of the old body
        let tmpDiv = document.createElement("div");
        tmpDiv.style.display = "none";
        tmpDiv.innerHTML = page.body;
        document.body.appendChild(tmpDiv);

        // Get the old header
        let oldHeader = tmpDiv.querySelector("header");
        if(oldHeader){
            oldHeader.remove();
        }
        console.log(page.title);
        console.log(oldHeader);
        console.log(tmpDiv);

        // Clone the new header inside the _smartdesigner div
        let smartdesigner = tmpDiv.querySelector("._smartdesigner");
        if(smartdesigner){
            const clonedHeader = header.cloneNode(true);
            smartdesigner.insertAdjacentElement("afterbegin", clonedHeader);
        }
        console.log(tmpDiv);
        console.log(page);

        // Insert the new body
        let newBody = tmpDiv.innerHTML;

        let url = BASE_URL + `api/v1/courses/${ENV.COURSE_ID}/pages/${page.page_id}`;
        let updated = await insertNewBody(url, newBody, page.title) //TODO: Make new url

        // Clean up and remove the temporary div
        tmpDiv.remove();
        if(!updated){
            console.log("Unable to update page");
        }

    }

    async function insertNewBody(url, body, title){
        let res = await fetch(url, {
            method: 'PUT',
            headers: {
                "Content-Type": "application/json",
                'X-CSRF-Token': CSRFtoken(),
            },
            body: JSON.stringify({
                "wiki_page": {
                    "title": title,
                    "body": body,
                }
            }),
        });
        if(res.status === 200){
            return true;
        } else {
            console.log("Unable to update page");
            return false;
        }
    }

    function showProgressModal(){
        // Remove any potential existing dialog
        let dialogs = document.querySelectorAll("dialog");
        for(const d of dialogs){
            d.remove();
        }
        // Main dialog with a div
        const dialog = document.createElement("dialog");
        const dialogDiv = document.createElement("div");
        dialog.appendChild(dialogDiv);

        // Dialog title
        const dialogHeader = document.createElement("h3");
        dialogHeader.innerText = "Oppdaterer sider";
        dialogDiv.appendChild(dialogHeader);

        // Updating page
        const updatingDiv = document.createElement("div");
        dialogDiv.appendChild(updatingDiv);

        // Cancel/finished button
        const finishBtn = document.createElement("button");
        finishBtn.innerText = "Avbryt";
        finishBtn.classList.add("btn", "btn-primary");
        dialogDiv.appendChild(finishBtn);

        finishBtn.addEventListener("click", ()=>{
            updating = false;
            dialog.close();
        });

        document.body.appendChild(dialog);
        dialog.showModal();

        return [updatingDiv, finishBtn];
    }

    function validPage(page, pagesStartingWith){

        // If the starting part of the page title is longer than the title, this can not be the page
        if(pagesStartingWith.length > page.title.length){
            return false;
        }

        if(pagesStartingWith === page.title.substring(0,pagesStartingWith.length)){
            return true;
        } else {
            return false;
        }

    }

    async function getAllPages(URL, pages = []){

        try{
            let res = await fetch(URL);
            if(res.status === 200){
                let data = await res.json();
                pages = pages.concat(data);
                let nextLink = findNextLink(res);
                if(nextLink){
                    return await getAllPages(nextLink, pages);
                } else {
                    return pages;
                }
            } else {
                console.log(res);
            }
        }catch(err){
            console.error(err);
        }
    }

    function showModal(){
        // Remove any existing dialogs to avoid multiple elements that has input field with same id.
        let dialogs = document.querySelectorAll("dialog");
        for(const d of dialogs){
            d.remove();
        }
        // Main dialog with a div
        const dialog = document.createElement("dialog");
        const dialogDiv = document.createElement("div");
        dialog.appendChild(dialogDiv);

        // Dialog title
        const dialogHeader = document.createElement("h3");
        dialogHeader.innerText = "Hvilke sider skal oppdateres?";
        dialogDiv.appendChild(dialogHeader);

        // Dialog input
        const dialogInputDiv = document.createElement("div");
        dialogInputDiv.style.display = "flex";
        dialogInputDiv.style.flexDirection = "column";
        dialogInputDiv.innerHTML = '<label for="">Sider som begynner med: </label><input type="text" id="uia__page_start" />';
        dialogDiv.appendChild(dialogInputDiv);

        // Buttons
        const dialogBtnDiv = document.createElement("div");
        dialogBtnDiv.style.display = "flex";
        dialogBtnDiv.style.justifyContent = "space-between";
        dialogDiv.appendChild(dialogBtnDiv);

        const acceptBtn = document.createElement("button");
        acceptBtn.innerText = "Oppdater";
        acceptBtn.classList.add("btn", "btn-primary");
        dialogBtnDiv.appendChild(acceptBtn);
        acceptBtn.addEventListener("click", ()=>{
            dialog.close();
            updateHeader();
        });

        const cancelBtn = document.createElement("button");
        cancelBtn.innerText = "Avbryt";
        acceptBtn.classList.add("btn");
        dialogBtnDiv.appendChild(cancelBtn);
        cancelBtn.addEventListener("click", ()=>{dialog.close();});

        document.body.appendChild(dialog);

        dialog.showModal();

    }

    const CSRFtoken = function() {
        return decodeURIComponent((document.cookie.match('(^|;) *_csrf_token=([^;]*)') || '')[2])
    }

    function findNextLink(results){
        let responseHeaders = [...results.headers];
        let linkHeader = responseHeaders.find((el) => el[0].toLowerCase() === "link");
        let textArray = linkHeader[1].split(",");
        // Go through and see if we find a next link
        for(const link of textArray){
            let [url, rel] = link.split(";");
            if(rel.includes("next")){
                // Remove the < and > from start and end.
                return url.substring(1,url.length - 1);
            }
        }
        return false; // No next-link was found.
    }
})();